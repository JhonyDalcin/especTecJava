/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.javai.atividade01;

import com.javai.model.Veiculo;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Atividade 01 da disciplina JAVA 01 - Especializacao JAVA UTFPR
 * @author jhonydalcin
 */
public class Teste {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        int numeroInstancias = 5;
        Veiculo[] listaVeiculos = new Veiculo[numeroInstancias];
        
        String placa, marca, modelo, cor;
        float velMax;
        int qtdRodas, qtdPist, potencia;
        
        for (int i=0; i<numeroInstancias; i++){
            
            System.out.printf("\nInsira os dados do veículo %d ---------------\n", i+1);
            try {
                System.out.printf("Insira a placa: ");
                placa = sc.nextLine();
                System.out.printf("Insira a marca: ");
                marca = sc.nextLine();
                System.out.printf("Insira o modelo: ");
                modelo = sc.nextLine();
                System.out.printf("Insira a cor: ");
                cor = sc.nextLine();
                System.out.printf("Insira a velocidade máxima: ");
                velMax = sc.nextFloat();
                if (velMax <= 0) {
                    throw new IllegalArgumentException ("\n\nVelocidade deve ser maior que 0\n");
                }
                System.out.printf("Insira a quantidade de rodas: ");
                qtdRodas = sc.nextInt();
                System.out.printf("Insira a quantidade de pistões: ");
                qtdPist = sc.nextInt();
                if (qtdPist <= 0){
                    throw new IllegalArgumentException ("\n\nQuantiade de pistões deve ser maior que 0\n");
                }
                System.out.printf("Insira a potência: ");
                potencia = sc.nextInt();
                sc.nextLine();
                if (potencia <= 0) {
                    throw new IllegalArgumentException ("\n\nPotência deve ser maior que 0\n");
                }
                
                listaVeiculos[i] = new Veiculo(placa, marca, modelo, cor, velMax, qtdRodas, qtdPist, potencia);
                
            } catch (InputMismatchException e) {
                System.out.println(e);
            }
        }
        
        System.out.println("\nImprimindo veículos registrados ---------------\n");
        for (Veiculo veiculo : listaVeiculos) {
            veiculo.toString();
        } 
        
        System.out.println("\nRequisito a. Instanciando via construtor standart e imprimindo resultado:\n");
        Veiculo veiculoStandart = new Veiculo();
        veiculoStandart.toString();
        sc.close();
    }
}
